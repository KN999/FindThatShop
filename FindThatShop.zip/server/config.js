module.exports = {
    'secret' : 'supersecret'
};